import java.io.IOException;


import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Reducer;


public class myReducer extends Reducer<Text, Text, Text, Text> {
	
public void reduce(Text inpK, Iterable<Text> inpV, Context c) throws IOException, InterruptedException{
		
double amount=0.0;
		
String name=null;
		
for(Text each: inpV){
			
String[] eachVal = each.toString().split(":");
			
if(eachVal[0].equals("amt"))
				
amount+=Double.parseDouble(eachVal[1]);
			
else
				
name =eachVal[1];				
		
}
		
String[] key=inpK.toString().split(":");
		
c.write(new Text(key[1]), new Text(" "+name+" "+amount));
	
}

}
